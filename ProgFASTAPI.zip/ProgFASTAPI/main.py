import mysql.connector
from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request
from fastapi.staticfiles import StaticFiles
import hashlib

app = FastAPI()


templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")


def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',  
        password='',  
        database='supermercato' 
    )
    return connection


def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(stored_password, entered_password):
    return stored_password == hash_password(entered_password)


@app.get("/")
def root():
    return RedirectResponse(url="/login")


@app.post("/register")
def register(username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    existing_user = cursor.fetchone()

    if existing_user:
        cursor.close()
        connection.close()
        raise HTTPException(status_code=400, detail="Username già esistente")

    hashed_password = hash_password(password)

    cursor.execute("INSERT INTO utenti (username, email, password, ruolo) VALUES (%s, %s, %s, %s)",
                   (username, email, hashed_password, 'cliente'))
    connection.commit()

    cursor.close()
    connection.close()

    return {"message": f"{username} registrato con successo"}


@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    user = cursor.fetchone()

    if user is None:
        cursor.close()
        connection.close()
        raise HTTPException(status_code=401, detail="Credenziali non valide")

    stored_password = user[3]
    if not verify_password(stored_password, password):
        cursor.close()
        connection.close()
        raise HTTPException(status_code=401, detail="Credenziali non valide")

    cursor.close()
    connection.close()

    return {"message": f"Benvenuto {username}"}


@app.post("/cambiaPass")
def change_password(username: str = Form(...), old_password: str = Form(...), new_password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    user = cursor.fetchone()

    if user is None or not verify_password(user[3], old_password): 
        cursor.close()
        connection.close()
        raise HTTPException(status_code=400, detail="Password attuale errata")

    hashed_password = hash_password(new_password)
    cursor.execute("UPDATE utenti SET password = %s WHERE username = %s", (hashed_password, username))
    connection.commit()

    cursor.close()
    connection.close()

    return {"message": "Password cambiata con successo"}


@app.get("/login", response_class=HTMLResponse)
def get_login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/register", response_class=HTMLResponse)
def get_register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/cambiaPass", response_class=HTMLResponse)
def get_change_password_page(request: Request):
    return templates.TemplateResponse("cambiaPass.html", {"request": request})
