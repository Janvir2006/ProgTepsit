import mysql.connector
from fastapi import FastAPI, Form, HTTPException, Depends, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi import Request
from fastapi.staticfiles import StaticFiles
import hashlib

app = FastAPI()


templates = Jinja2Templates(directory="templates")

app.mount("/static", StaticFiles(directory="static"), name="static")


def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',  
        password='',  
        database='supermercato' 
    )
    return connection


def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(stored_password, entered_password):
    return stored_password == hash_password(entered_password)


def is_admin(user_role):
    return user_role == 'admin'


def get_current_user(request: Request):
    username = request.cookies.get("username")
    if not username:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Non autenticato")
    
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    connection.close()

    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Utente non trovato")
    
    return user


def get_current_user_role(request: Request):
    user = get_current_user(request)
    if not is_admin(user[4]):  
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Accesso vietato. Solo gli admin possono accedere.")
    return user

@app.get("/")
def root():
    return RedirectResponse(url="/login")

@app.post("/register")
def register(request: Request, username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    existing_user = cursor.fetchone()

    if existing_user:
        cursor.close()
        connection.close()
        return templates.TemplateResponse("register.html", {"request": request, "error": "Username già esistente"})

    hashed_password = hash_password(password)

    cursor.execute("INSERT INTO utenti (username, email, password, ruolo) VALUES (%s, %s, %s, %s)",
                   (username, email, hashed_password, 'cliente'))
    connection.commit()

    cursor.close()
    connection.close()

    return templates.TemplateResponse("register.html", {"request": request, "success": f"{username} registrato con successo"})

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    user = cursor.fetchone()

    if user is None or not verify_password(user[3], password):  
        cursor.close()
        connection.close()
        return templates.TemplateResponse("login.html", {"request": request, "error": "Credenziali non valide"})

    response = RedirectResponse(url="/admin_dashboard" if user[4] == "admin" else "/user_dashboard")
    response.set_cookie(key="username", value=username, httponly=True)  
    cursor.close()
    connection.close()

    return response



@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/admin_dashboard", response_class=HTMLResponse)
def adminDash(request: Request):
    return templates.TemplateResponse("admin_dashboard.html", {"request": request})


@app.post("/admin_dashboard", response_class=HTMLResponse)
def admin_dashboard(request: Request, user: tuple = Depends(get_current_user_role), account_type: str = Form(None), username: str = Form(None), action: str = Form(None)):
    connection = get_db_connection()
    cursor = connection.cursor()

    message = None 

    if account_type and username and action: 
        if account_type == "utente":
            table_name = "utenti"
        elif account_type == "dipendente":
            table_name = "dipendenti"
        elif account_type == "fornitore":
            table_name = "fornitori"
        else:
            cursor.close()
            connection.close()
            raise HTTPException(status_code=400, detail="Tipo di account non valido")

        if action == "aggiungi":
            cursor.execute(f"INSERT INTO {table_name} (username) VALUES (%s)", (username,))
            connection.commit()
            message = f"{account_type.capitalize()} {username} aggiunto con successo"
        elif action == "modifica":
            cursor.execute(f"UPDATE {table_name} SET username = %s WHERE username = %s", (username, username))
            connection.commit()
            message = f"{account_type.capitalize()} {username} modificato con successo"
        elif action == "elimina":
            cursor.execute(f"DELETE FROM {table_name} WHERE username = %s", (username,))
            connection.commit()
            message = f"{account_type.capitalize()} {username} eliminato con successo"
        else:
            cursor.close()
            connection.close()
            raise HTTPException(status_code=400, detail="Azione non valida")

    cursor.close()
    connection.close()

    return templates.TemplateResponse("admin_dashboard.html", {"request": request, "success": message})

@app.get("/cambiaPass", response_class=HTMLResponse)
def change_password_page(request: Request):
    return templates.TemplateResponse("cambiaPass.html", {"request": request})

@app.post("/cambiaPass")
def change_password(request: Request, username: str = Form(...), old_password: str = Form(...), new_password: str = Form(...)):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM utenti WHERE username = %s", (username,))
    user = cursor.fetchone()

    if user is None:
        cursor.close()
        connection.close()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Utente non trovato")

    if not verify_password(user[3], old_password): 
        cursor.close()
        connection.close()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Password attuale non corretta")

    hashed_new_password = hash_password(new_password)

    cursor.execute("UPDATE utenti SET password = %s WHERE username = %s", (hashed_new_password, username))
    connection.commit()

    cursor.close()
    connection.close()

    return templates.TemplateResponse("cambiaPass.html", {"request": request, "success": "Password cambiata con successo!"})
