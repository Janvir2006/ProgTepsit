// Funzione globale per aggiungere un prodotto al carrello
window.aggiungiAlCarrello = function(prodottoId, quantita = 1) {
    fetch('/carrello/aggiungi', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prodotto_id: prodottoId, quantita: quantita })
    })
    .then(response => {
        if (!response.ok) throw new Error('Errore nell\'aggiunta al carrello');
        return response.json();
    })
    .then(data => {
        alert('Prodotto aggiunto al carrello!');
        aggiornaContatoreCarrello(data.totale_articoli); // Aggiorna il contatore del carrello
    })
    .catch(error => {
        alert(`Errore: ${error.message}`);
    });
};

// Funzione per aggiornare il contatore nel menu
function aggiornaContatoreCarrello(totaleArticoli) {
    const cartCount = document.querySelector('.nav-cart span');
    if (cartCount) {
        cartCount.textContent = totaleArticoli;
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const carrelloContainer = document.getElementById('carrello-items');
    const totaleElement = document.getElementById('carrello-totale');
    const svuotaBtn = document.getElementById('svuota-carrello');

    // Verifica che svuotaBtn esista nel DOM
    if (!svuotaBtn) {
        console.error('Elemento con id "svuota-carrello" non trovato nel DOM');
        return;
    }

    // Funzione per formattare il prezzo
    const formattaPrezzo = (prezzo) => {
        return '€' + parseFloat(prezzo).toFixed(2);
    };

    // Funzione per aggiornare il carrello
    async function aggiornaCarrello() {
        try {
            const response = await fetch('/api/carrello');
            if (!response.ok) throw new Error('Errore nel caricamento del carrello');
            const items = await response.json();

            // Calcola il totale
            const totale = items.reduce((sum, item) => sum + (item.prezzo * item.quantita), 0);

            // Se il carrello è vuoto
            carrelloContainer.innerHTML = '';
            if (items.length === 0) {
                carrelloContainer.innerHTML = '<p style="text-align:center; padding:40px 0">Il carrello è vuoto</p>';
                totaleElement.textContent = formattaPrezzo(0);
                return;
            }

            // Popola il carrello con gli articoli
            items.forEach(item => {
                const itemElement = document.createElement('div');
                itemElement.className = 'carrello-item';
                itemElement.innerHTML = `
                    <div class="carrello-item-img">
                        <img src="/static/images/${item.immagine}" alt="${item.nome}" 
                             onerror="this.src='/static/images/placeholder.png'">
                        <span>${item.nome}</span>
                    </div>
                    <div class="carrello-item-prezzo">${formattaPrezzo(item.prezzo)}</div>
                    <div class="carrello-item-quantita">
                        <input type="number" value="${item.quantita}" min="1" 
                               onchange="aggiornaQuantita(${item.id}, this.value)">
                    </div>
                    <div class="carrello-item-totale">${formattaPrezzo(item.prezzo * item.quantita)}</div>
                `;
                carrelloContainer.appendChild(itemElement);
            });

            // Aggiorna il totale nel carrello
            totaleElement.textContent = formattaPrezzo(totale);
        } catch (error) {
            console.error('Errore:', error);
            carrelloContainer.innerHTML = `
                <p style="text-align:center; color:red; padding:20px">
                    Errore nel caricamento del carrello: ${error.message}
                </p>
            `;
        }
    }

    // Funzione per aggiornare la quantità del prodotto
    window.aggiornaQuantita = async (prodottoId, quantita) => {
        quantita = parseInt(quantita);
        if (isNaN(quantita) || quantita < 1) {
            alert("La quantità deve essere un numero maggiore di zero.");
            return;
        }

        try {
            const response = await fetch(`/carrello/aggiorna/${prodottoId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ quantita })
            });

            if (!response.ok) throw new Error('Errore nell\'aggiornamento');

            await aggiornaCarrello(); // Ricarica il carrello dopo l'aggiornamento
        } catch (error) {
            alert(`Errore: ${error.message}`);
        }
    };

    // Gestione svuota carrello
    svuotaBtn.addEventListener('click', async () => {
        if (!confirm('Sei sicuro di voler svuotare il carrello?')) return;

        try {
            const response = await fetch('/carrello/svuota', { method: 'POST' });
            if (!response.ok) throw new Error('Errore nello svuotamento');

            await aggiornaCarrello(); // Ricarica il carrello dopo lo svuotamento
            alert('Carrello svuotato con successo!');
        } catch (error) {
            alert(`Errore: ${error.message}`);
        }
    });

    // Carica inizialmente il carrello
    await aggiornaCarrello();
});
